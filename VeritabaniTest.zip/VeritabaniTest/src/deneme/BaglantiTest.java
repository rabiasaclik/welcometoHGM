package deneme;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BaglantiTest {

	public static void main(String[] args) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/harita", "harita_user", "harita");

			PreparedStatement stmt = conn.prepareStatement("select * from personel");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String tcNo = rs.getString("tcno");
				String adi = rs.getString("adi");
				String soyadi = rs.getString("soyadi");
				System.out.println(tcNo + ", " + adi + ", " + soyadi);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
