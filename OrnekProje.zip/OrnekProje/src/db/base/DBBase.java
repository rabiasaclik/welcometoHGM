package db.base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBBase {
	private static String accessDBPath = "c:\\proje\\Personel.accdb";
	private static String url = "jdbc:ucanaccess://" + accessDBPath;
	private static ThreadLocal<Connection> connection = new ThreadLocal<Connection>();
	static {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	protected Connection getConnection() {
		Connection c = DBBase.connection.get();
		if (c == null) {
			try {
				c = DriverManager.getConnection(url);
				DBBase.connection.set(c);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return c;
	}

	protected void close(PreparedStatement stmt, ResultSet rs) {
		try {
			rs.close();
		} catch (Exception e) {
		} finally {
			close(stmt);
		}
	}

	protected void close(PreparedStatement stmt) {
		try {
			stmt.close();
		} catch (Exception e) {
		}
	}

	public static void closeConnection() {
		try {
			connection.get().close();
		} catch (Exception e) {
		}
	}

}
