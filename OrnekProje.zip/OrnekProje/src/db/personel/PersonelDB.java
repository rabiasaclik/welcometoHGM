package db.personel;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Personel;
import db.base.DBBase;

public class PersonelDB extends DBBase {
	public List<Personel> getPersoneller() {
		List<Personel> personeller = new ArrayList<>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement("select * from personel");
			rs = stmt.executeQuery();
			while (rs.next()) {
				Personel personel = new Personel();
				personel.setId(rs.getInt("id"));
				personel.setAdi(rs.getString("adi"));
				personel.setEmail(rs.getString("eposta"));
				personel.setResim(rs.getString("resim"));
				personeller.add(personel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt, rs);
		}
		return personeller;
	}

	public Personel getPersonel(int id) {
		Personel personel = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = getConnection().prepareStatement("select * from personel where id = ?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				personel = new Personel();
				personel.setId(rs.getInt("id"));
				personel.setAdi(rs.getString("adi"));
				personel.setEmail(rs.getString("eposta"));
				personel.setResim(rs.getString("resim"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(stmt, rs);
		}
		return personel;
	}

}
