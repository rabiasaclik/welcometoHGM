package business;

import java.util.List;

import bean.Personel;
import db.base.DBBase;
import db.personel.PersonelDB;

public class PersonelBusiness {
	public List<Personel> getPersoneller() {
		try {
			return new PersonelDB().getPersoneller();
		} finally {
			DBBase.closeConnection();
		}
	}

	public Personel getPersonel(int id) {
		try {
			return new PersonelDB().getPersonel(id);
		} finally {
			DBBase.closeConnection();
		}
	}
}
