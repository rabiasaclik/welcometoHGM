package servlets;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import business.PersonelBusiness;

@WebServlet("/resim")
public class ResimServlet extends HttpServlet {
	private static final long serialVersionUID = -3138522330438725545L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("image/jpeg");
		int id = Integer.parseInt(req.getParameter("id"));
		String resimAdi = new PersonelBusiness().getPersonel(id).getResim();
		File f = new File("c:/proje/resimler/" + resimAdi);
		BufferedImage bi = ImageIO.read(f);
		OutputStream out = resp.getOutputStream();
		ImageIO.write(bi, "jpg", out);
		out.close();
	}
}
