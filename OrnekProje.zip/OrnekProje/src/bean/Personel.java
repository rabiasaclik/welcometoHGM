package bean;

public class Personel {
	private int id;
	private String adi;
	private String email;
	private String resim;

	public Personel() {
	}

	public Personel(int id, String adi, String email, String resim) {
		this.id = id;
		this.adi = adi;
		this.email = email;
		this.resim = resim;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdi() {
		return adi;
	}

	public void setAdi(String adi) {
		this.adi = adi;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getResim() {
		return resim;
	}

	public void setResim(String resim) {
		this.resim = resim;
	}
}
