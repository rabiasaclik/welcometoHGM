package servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Birlik;
import beans.Personel;
import business.BirlikBusiness;
import business.PersonelBusiness;

@WebServlet("/listeGetir")
public class ListeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tip = request.getParameter("tip");
		if ("1".equals(tip)) {
			// Personel Listesi istenmistir
			List<Personel> personeller = new PersonelBusiness().getPersoneller();
			request.setAttribute("liste", personeller);
			request.getRequestDispatcher("/personelListesi.jsp").forward(request, response);
		} else if ("2".equals(tip)) {
			// Birlik Listesi istenmistir
			List<Birlik> birlikler = new BirlikBusiness().getBirlikler();
			request.setAttribute("liste", birlikler);
			request.getRequestDispatcher("/birlikListesi.jsp").forward(request, response);
		}
	}

}
