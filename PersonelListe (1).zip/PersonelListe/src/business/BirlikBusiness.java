package business;

import java.util.List;

import beans.Birlik;
import db.BirlikDB;

public class BirlikBusiness {
	public List<Birlik> getBirlikler() {
		return new BirlikDB().getBirlikListesi();
	}
}
