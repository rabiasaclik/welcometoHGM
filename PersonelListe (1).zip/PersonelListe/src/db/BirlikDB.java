package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Birlik;

public class BirlikDB extends DBBase {
	public List<Birlik> getBirlikListesi() {
		List<Birlik> birlikler = new ArrayList<Birlik>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement("select * from birlik");
			rs = stmt.executeQuery();
			while (rs.next()) {
				Birlik birlik = new Birlik();
				birlik.setId(rs.getInt("id"));
				birlik.setMevcut(rs.getInt("mevcut"));
				birlik.setAdi(rs.getString("adi"));
				birlik.setSehir(rs.getString("sehir"));
				birlikler.add(birlik);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, stmt);
			closeConnection(conn);
		}
		return birlikler;
	}
}
